# Add project specific ProGuard rules here.
-keep class com.spamguard.detector.data.model.** { *; }
-keep class com.spamguard.detector.ml.** { *; }
