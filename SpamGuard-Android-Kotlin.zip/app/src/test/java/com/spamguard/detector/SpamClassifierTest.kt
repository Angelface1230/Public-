package com.spamguard.detector

import org.junit.Assert.*
import org.junit.Test

class SpamClassifierTest {
    @Test
    fun testSpamDetectionLogic() {
        val testSpam = "URGENT! You won $10,000 cash prize! Call 09061701461 to claim your reward"
        assertTrue(testSpam.contains("URGENT", ignoreCase = true))
        assertTrue(testSpam.contains("claim", ignoreCase = true))
    }
}
