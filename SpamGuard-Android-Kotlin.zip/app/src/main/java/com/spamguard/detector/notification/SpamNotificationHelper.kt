package com.spamguard.detector.notification

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.spamguard.detector.ui.MainActivity

/**
 * Helper to display high-priority notifications using pure Android framework APIs.
 * Eliminates all external library dependencies so it compiles and resolves instantly.
 */
object SpamNotificationHelper {

    fun showSpamAlert(
        context: Context,
        notificationId: Int,
        sender: String,
        body: String,
        category: String,
        confidence: Int
    ) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_NAVIGATE_TO", "quarantine")
            putExtra("EXTRA_HIGHLIGHT_SENDER", sender)
        }
        val pendingOpenIntent = PendingIntent.getActivity(
            context,
            notificationId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snippet = if (body.length > 90) body.take(90) + "..." else body
        val channelId = "channel_spam_alerts"

        val builder = Notification.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("⚠️ Suspicious SMS: $category")
            .setContentText("From $sender ($confidence% risk): $snippet")
            .setStyle(
                Notification.BigTextStyle()
                    .bigText("Threat Detected: $category ($confidence% confidence)\n\nFrom: $sender\n\nMessage: $body\n\nRecommended Action: Do not click any links or call numbers provided.")
            )
            .setAutoCancel(true)
            .setColor(0xFFD32F2F.toInt())
            .setContentIntent(pendingOpenIntent)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(notificationId, builder.build())
    }
}
