package com.spamguard.detector

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import com.spamguard.detector.data.local.SpamGuardDatabase
import com.spamguard.detector.ml.SpamClassifierEngine

/**
 * Main application class initializing database, notification channels,
 * and machine learning classifier engine for on-device spam detection.
 */
class SpamGuardApplication : Application() {

    lateinit var database: SpamGuardDatabase
        private set

    lateinit var classifierEngine: SpamClassifierEngine
        private set

    companion object {
        const val CHANNEL_SPAM_ALERTS = "channel_spam_alerts"
        const val CHANNEL_SYSTEM_STATUS = "channel_system_status"
        lateinit var instance: SpamGuardApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // 1. Initialize Room Database
        database = SpamGuardDatabase.getDatabase(this)

        // 2. Initialize On-Device ML Classifier Engine
        classifierEngine = SpamClassifierEngine(this)

        // 3. Create Notification Channels for Android 8.0+ (API 26+)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // High Priority Spam Alert Channel with custom alert sound
            val spamAlertSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
                .build()

            val spamChannel = NotificationChannel(
                CHANNEL_SPAM_ALERTS,
                getString(R.string.channel_spam_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.channel_spam_desc)
                enableLights(true)
                lightColor = android.graphics.Color.RED
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 150, 250)
                setSound(spamAlertSound, audioAttributes)
            }

            // System Protection Channel (Low Importance)
            val statusChannel = NotificationChannel(
                CHANNEL_SYSTEM_STATUS,
                getString(R.string.channel_service_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_service_desc)
            }

            notificationManager.createNotificationChannels(listOf(spamChannel, statusChannel))
        }
    }
}
