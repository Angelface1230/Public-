package com.spamguard.detector.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen() {
    var sensitivityThreshold by remember { mutableFloatStateOf(0.50f) }
    var soundAlertsEnabled by remember { mutableStateOf(true) }
    var autoQuarantine by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("Protection Settings", style = MaterialTheme.typography.titleLarge)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Spam Detection Sensitivity", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Threshold: ${(sensitivityThreshold * 100).toInt()}%",
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = sensitivityThreshold,
                    onValueChange = { sensitivityThreshold = it },
                    valueRange = 0.2f..0.9f
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Urgent Heads-Up Notifications")
                    Switch(checked = soundAlertsEnabled, onCheckedChange = { soundAlertsEnabled = it })
                }
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Auto-Quarantine Threats")
                    Switch(checked = autoQuarantine, onCheckedChange = { autoQuarantine = it })
                }
            }
        }
    }
}
