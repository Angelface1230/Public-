package com.spamguard.detector.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.spamguard.detector.data.model.SmsMessageItem

@Database(entities = [SmsMessageItem::class], version = 1, exportSchema = false)
abstract class SpamGuardDatabase : RoomDatabase() {
    abstract fun smsDao(): SmsDao

    companion object {
        @Volatile
        private var INSTANCE: SpamGuardDatabase? = null

        fun getDatabase(context: Context): SpamGuardDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SpamGuardDatabase::class.java,
                    "spam_guard.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
