package com.spamguard.detector.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.spamguard.detector.SpamGuardApplication
import com.spamguard.detector.data.model.SmsMessageItem
import com.spamguard.detector.notification.SpamNotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * BroadcastReceiver triggered whenever an incoming SMS arrives on the device.
 * Automatically intercepts, classifies the message payload with on-device ML,
 * stores the result in Room database, and alerts user with heads-up notification if spam.
 */
class SmsBroadcastReceiver : BroadcastReceiver() {

    private val TAG = "SpamGuardReceiver"

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            if (messages.isNullOrEmpty()) return

            val app = context.applicationContext as? SpamGuardApplication ?: return
            val database = app.database
            val classifier = app.classifierEngine

            // Assemble multi-part SMS if necessary
            val sender = messages[0].displayOriginatingAddress ?: "Unknown"
            val bodyBuilder = StringBuilder()
            for (msg in messages) {
                msg.messageBody?.let { bodyBuilder.append(it) }
            }
            val messageBody = bodyBuilder.toString()

            Log.d(TAG, "Incoming SMS from $sender: length=${messageBody.length}")

            // Run analysis asynchronously
            CoroutineScope(Dispatchers.IO).launch {
                // Check whitelist first
                if (database.smsDao().isSenderWhitelisted(sender)) {
                    Log.d(TAG, "Sender $sender is whitelisted by user. Skipping alert.")
                    return@launch
                }

                // Check blacklist
                val isBlacklisted = database.smsDao().isSenderBlacklisted(sender)

                // Run ML Classification
                val result = classifier.classify(messageBody, sender)
                val finalIsSpam = result.isSpam || isBlacklisted

                // Persist into Room Database
                val item = SmsMessageItem(
                    sender = sender,
                    body = messageBody,
                    timestamp = System.currentTimeMillis(),
                    isSpam = finalIsSpam,
                    spamScore = result.spamProbability,
                    confidencePercent = result.confidencePercentage,
                    scamCategory = if (isBlacklisted) "Blacklisted Sender" else result.primaryCategory,
                    highlightedTokens = result.matchedSpamTokens.joinToString(","),
                    isQuarantined = finalIsSpam
                )
                val insertedId = database.smsDao().insertMessage(item)

                // If classified as spam, notify the user with rich heads-up alert
                if (finalIsSpam) {
                    SpamNotificationHelper.showSpamAlert(
                        context = context,
                        notificationId = insertedId.toInt(),
                        sender = sender,
                        body = messageBody,
                        category = item.scamCategory,
                        confidence = result.confidencePercentage
                    )
                }
            }
        }
    }
}
