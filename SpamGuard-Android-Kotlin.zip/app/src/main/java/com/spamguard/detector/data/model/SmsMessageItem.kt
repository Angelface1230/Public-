package com.spamguard.detector.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity representing an intercepted or scanned SMS message stored in Room DB.
 */
@Entity(tableName = "sms_messages")
data class SmsMessageItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String,
    val body: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSpam: Boolean,
    val spamScore: Float, // 0.0f to 1.0f probability
    val confidencePercent: Int,
    val scamCategory: String, // e.g. "Phishing", "Financial Scam", "Prize Lottery", "Safe"
    val highlightedTokens: String, // Comma separated spam tokens identified
    val isQuarantined: Boolean = isSpam,
    val isUserWhitelisted: Boolean = false,
    val isUserBlacklisted: Boolean = false
)
