package com.spamguard.detector.data.local

import androidx.room.*
import com.spamguard.detector.data.model.SmsMessageItem
import kotlinx.coroutines.flow.Flow

@Dao
interface SmsDao {
    @Query("SELECT * FROM sms_messages ORDER BY timestamp DESC")
    fun getAllMessagesFlow(): Flow<List<SmsMessageItem>>

    @Query("SELECT * FROM sms_messages WHERE isSpam = 1 ORDER BY timestamp DESC")
    fun getQuarantinedSpamFlow(): Flow<List<SmsMessageItem>>

    @Query("SELECT COUNT(*) FROM sms_messages")
    fun getTotalCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sms_messages WHERE isSpam = 1")
    fun getSpamCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: SmsMessageItem): Long

    @Update
    suspend fun updateMessage(message: SmsMessageItem)

    @Delete
    suspend fun deleteMessage(message: SmsMessageItem)

    @Query("DELETE FROM sms_messages WHERE isSpam = 1")
    suspend fun clearAllSpam()

    @Query("UPDATE sms_messages SET isSpam = 0, isQuarantined = 0, isUserWhitelisted = 1 WHERE id = :messageId")
    suspend fun markAsSafe(messageId: Long)

    @Query("UPDATE sms_messages SET isUserBlacklisted = 1 WHERE sender = :sender")
    suspend fun blacklistSender(sender: String)

    @Query("SELECT EXISTS(SELECT 1 FROM sms_messages WHERE sender = :sender AND isUserBlacklisted = 1)")
    suspend fun isSenderBlacklisted(sender: String): Boolean

    @Query("SELECT EXISTS(SELECT 1 FROM sms_messages WHERE sender = :sender AND isUserWhitelisted = 1)")
    suspend fun isSenderWhitelisted(sender: String): Boolean
}
