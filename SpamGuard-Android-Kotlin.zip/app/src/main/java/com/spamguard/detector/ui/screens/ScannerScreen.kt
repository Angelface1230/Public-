package com.spamguard.detector.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.spamguard.detector.SpamGuardApplication
import com.spamguard.detector.data.model.SpamClassificationResult

@Composable
fun ScannerScreen() {
    val classifier = remember { SpamGuardApplication.instance.classifierEngine }
    var inputText by remember { mutableStateOf("Congratulations! You won a $1,000 Walmart gift card. Click http://bit.ly/claim-now urgently to claim.") }
    var result by remember { mutableStateOf<SpamClassificationResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Interactive SMS Spam Analyzer", style = MaterialTheme.typography.titleMedium)

        OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            label = { Text("Paste or type SMS content") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )

        Button(
            onClick = {
                result = classifier.classify(inputText, "Tester")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Run On-Device ML Classification")
        }

        result?.let { res ->
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (res.isSpam) Color(0xFFFFEBEE) else Color(0xFFE8F5E9)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (res.isSpam) "⚠️ SPAM / FRAUD DETECTED" else "✅ LEGITIMATE MESSAGE (HAM)",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (res.isSpam) Color(0xFFC62828) else Color(0xFF2E7D32)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Risk Probability: ${res.confidencePercentage}%")
                    Text("Category: ${res.primaryCategory}")
                    Text("Triggered Tokens: ${res.matchedSpamTokens.joinToString(", ")}")
                    Spacer(Modifier.height(8.dp))
                    Text(res.explanation, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
