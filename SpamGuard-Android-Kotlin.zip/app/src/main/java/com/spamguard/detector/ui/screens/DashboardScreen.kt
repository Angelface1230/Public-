package com.spamguard.detector.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.spamguard.detector.SpamGuardApplication
import kotlinx.coroutines.flow.collectLatest

@Composable
fun DashboardScreen(onNavigateToScanner: () -> Unit) {
    val database = SpamGuardApplication.instance.database
    val totalCount by database.smsDao().getTotalCountFlow().collectAsState(initial = 0)
    val spamCount by database.smsDao().getSpamCountFlow().collectAsState(initial = 0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Real-Time Protection Shield Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "Active Shield On",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "On-device ML analyzing incoming SMS",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            // Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Total Scanned", style = MaterialTheme.typography.labelMedium)
                        Text(
                            text = totalCount.toString(),
                            style = MaterialTheme.typography.headlineMedium
                        )
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Spam Blocked", style = MaterialTheme.typography.labelMedium, color = Color(0xFFC62828))
                        Text(
                            text = spamCount.toString(),
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color(0xFFC62828)
                        )
                    }
                }
            }
        }

        item {
            Button(
                onClick = onNavigateToScanner,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Test SMS Analyzer Bench")
            }
        }
    }
}
