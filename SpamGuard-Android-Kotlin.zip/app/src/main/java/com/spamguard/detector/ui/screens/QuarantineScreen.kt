package com.spamguard.detector.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.spamguard.detector.SpamGuardApplication
import kotlinx.coroutines.launch

@Composable
fun QuarantineScreen() {
    val database = SpamGuardApplication.instance.database
    val spamList by database.smsDao().getQuarantinedSpamFlow().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Quarantine Vault", style = MaterialTheme.typography.titleLarge)
            if (spamList.isNotEmpty()) {
                TextButton(onClick = {
                    coroutineScope.launch { database.smsDao().clearAllSpam() }
                }) {
                    Text("Clear All")
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        if (spamList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("No quarantined spam messages! Device is clean.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(spamList) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(item.sender, style = MaterialTheme.typography.titleSmall)
                                AssistChip(
                                    onClick = {},
                                    label = { Text("${item.confidencePercent}% Risk", color = Color.Red) }
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(item.body, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick = {
                                    coroutineScope.launch { database.smsDao().markAsSafe(item.id) }
                                }) {
                                    Text("Mark Safe")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
