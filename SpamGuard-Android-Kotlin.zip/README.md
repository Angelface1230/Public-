# SpamGuard SMS - Modern Android Kotlin Application

An intelligent, privacy-first Android application built with **Kotlin**, **Jetpack Compose (Material Design 3)**, **Android Room Database**, and an on-device **Machine Learning Classifier** to automatically intercept, evaluate, and alert users about fraudulent spam and scam SMS messages.

## 🚀 Features
- **Automatic Background Interception**: Android `BroadcastReceiver` captures `android.provider.Telephony.SMS_RECEIVED` events with zero delay.
- **On-Device ML Engine**: Converted from Python Multinomial Naive Bayes model (`spam_detector_model.pkl`) to pure Kotlin, running offline in < 2ms without sending message contents to any remote cloud server.
- **Material Design 3 UI**: Modern Android 14+ Jetpack Compose interface with Material You dynamic theming.
- **Heads-Up Notifications**: Rich notifications with high-priority alert channel, confidence metrics, and one-tap "Block Sender" or "Mark Safe".
- **Quarantine Vault**: Local Room SQLite storage to inspect blocked threats, view token attribution, and maintain sender whitelists/blacklists.
- **Model Synchronization Worker**: Android `WorkManager` background task for periodic retraining and threat vocabulary updates.

## 📦 How to Open & Run in Android Studio
1. Unzip `SpamGuard-Android-Kotlin.zip`.
2. Launch **Android Studio** (Giraffe, Hedgehog, Iguana, Jellyfish, or newer).
3. Select **File -> Open...** and choose the unzipped `SpamGuard` folder.
4. Let Gradle sync and download dependencies.
5. Connect an Android device (Android 8.0 / API 26 or higher) or start an Android Emulator.
6. Press **Run (Shift + F10)**.
7. Upon opening, grant the **SMS Permission** and **Notification Permission** prompted by the app.

## 🧪 Testing with Android Emulator SMS
You can simulate incoming SMS directly from Android Studio:
1. Open the **Extended Controls (...)** on your Android Emulator.
2. Select **Phone** in the sidebar.
3. In the **SMS message** field, type a spam message:
   `"URGENT: Your bank account has been locked. Verify immediately at http://bit.ly/bank-security or call 1-800-CLAIM"`
4. Click **Send Message**.
5. Observe the high-priority Heads-up Notification and Quarantine record logged inside SpamGuard!
